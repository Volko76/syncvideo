const socket = io();
const video = document.getElementById('video');
const playPauseButton = document.getElementById('playPause');

playPauseButton.addEventListener('click', () => {
  if (video.paused) {
    video.play();
    socket.emit('toggle_playback', { action: 'play' });
  } else {
    video.pause();
    socket.emit('toggle_playback', { action: 'pause' });
  }
});

socket.on('toggle_playback', (data) => {
  if (data.action === 'play') {
    if (video.paused) {
      video.play();
    }
  } else if (data.action === 'pause') {
    if (!video.paused) {
      video.pause();
    }
  }
});